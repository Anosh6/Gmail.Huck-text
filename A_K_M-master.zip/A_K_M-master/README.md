# A_K_M
قوی ترین ابزار هک و کرک  اکانت های فیسبوک از هر کشور     A K M 

#telegram  https://t.me/sultani1122


#دستورات


pkg update

 pkg upgrade

 pkg install git

 pkg install python

pkg install python2

 pip2 install mechanize

pip2 install requests


git clone https://github.com/mohammadjan1122/A_K_M

 cd A_K_M

chmod 777 A_K_M  
  
python2 A_K_M


Username  AKM


Password AKM
